% importing data

x = readtable('iris.dat');
disp(x);